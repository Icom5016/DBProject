from flask import jsonify, request
from dashdao.dashdao import DashDAO

class DashHandler:
    def mapToTotalLikesDict(self, row):
        result = {}
        result["likes"] = row[0]
        return result

    def mapToTotalDislikesDict(self, row):
        result = {}
        result["dislikes"] = row[0]
        return result

    def mapToTotalMsgDict(self, row):
        result = {}
        result["messages"] = row[0]
        return result

    def mapToTotalRepliesDict(self, row):
        result = {}
        result["replies"] = row[0]
        return result

    def mapToTotalActiveUsersDict(self, row):
        result = {}
        result["active_users"] = row[0]
        return result

    def mapToOrderedHashtagFrequencyDict(self, row):
        result = {}
        result["hashtag"] = row[0]
        result["frequency"] = row[1]
        return result

    def getOrderedHashtagFrequency(self, date):
        dao = DashDAO()
        result = dao.getOrderedHashtagFrequency(date)
        if result == None:
            return jsonify(Error="NOT FOUND"), 404
        else:
            mapped_result = []
            for r in result:
                mapped_result.append(self.mapToOrderedHashtagFrequencyDict(r))
            return jsonify(Trending=mapped_result)

    def getActiveUsersForDate(self, date):
        dao = DashDAO()
        result = dao.getActiveUsersForDate(date)
        if result == None:
            return jsonify(Error="NOT FOUND"), 404
        else :
            mapped = self.mapToTotalActiveUsersDict(result)
            return jsonify(Active_Users=mapped)

    def getTotalLikesPerDay(self, date):
        dao = DashDAO()
        result = dao.getLikesPerDate(date)
        if result == None:
            return jsonify(Error="NOT FOUND"), 404
        else :
            mapped = self.mapToTotalLikesDict(result)
            return jsonify(Message=mapped)

    def getTotalDislikesPerDay(self, date):
        dao = DashDAO()
        result = dao.getDislikesPerDate(date)
        if result == None:
            return jsonify(Error="NOT FOUND"), 404
        else :
            mapped = self.mapToTotalDislikesDict(result)
            return jsonify(Message=mapped)

    def getTotalRepliesPerDay(self, date):
        dao = DashDAO()
        result = dao.getTotalRepliesPerDate(date)
        if result == None:
            return jsonify(Error="NOT FOUND"), 404
        else :
            mapped = self.mapToTotalRepliesDict(result)
            return jsonify(Message=mapped)

    def getTotalMessagesPerDay(self, date):
        dao = DashDAO()
        result = dao.getTotalMessagesPerDate(date)
        if result == None:
            return jsonify(Error="NOT FOUND"), 404
        else :
            mapped = self.mapToTotalMsgDict(result)
            return jsonify(Message=mapped)

    ##############################################
    def buildHashtagCounts(self, hashtag_counts):
        result = []
        id = 1
        for H in hashtag_counts:
            D = {}
            D['id'] = id
            D['name'] = H[0]
            D['count'] = H[1]
            result.append(D)
            id += 1
        return result

    def getCountByHashtagId(self):
        dao = DashDAO()
        result = dao.getCountByHashtagId()
        #print(self.build_part_counts(result))
        return jsonify(HashtagCounts = self.buildHashtagCounts(result)), 200

    def buildActiveUserCounts(self, user_counts):
        result = []
        for U in user_counts:
            D = {}
            D['id'] = U[0]
            D['name'] = U[1]
            D['count'] = U[2]
            result.append(D)
        return result

    def getCountByActiveUsersId(self):
        dao = DashDAO()
        result = dao.getCountByActiveUsersId()
        #print(self.build_part_counts(result))
        return jsonify(UserCounts = self.buildActiveUserCounts(result)), 200

    def buildDailyCount(self, counts):
        result = []
        for C in counts:
            D = {}
            D['date'] = C[0]
            D['count'] = C[1]
            result.append(D)
        return result

    def getCountByDislikesId(self):
        dao = DashDAO()
        result = dao.getCountByDislikesId()
        #print(self.build_part_counts(result))
        return jsonify(DislikesCounts = self.buildDailyCount(result)), 200

    def getCountByLikesId(self):
        dao = DashDAO()
        result = dao.getCountByLikesId()
        #print(self.build_part_counts(result))
        return jsonify(LikesCounts = self.buildDailyCount(result)), 200

    def getCountByMessagesId(self):
        dao = DashDAO()
        result = dao.getCountByMessagesId()
        #print(self.build_part_counts(result))
        return jsonify(MessagesCounts = self.buildDailyCount(result)), 200

    def getCountByRepliesId(self):
        dao = DashDAO()
        result = dao.getCountByRepliesId()
        #print(self.build_part_counts(result))
        return jsonify(RepliesCounts = self.buildDailyCount(result)), 200