from config.dbconfig import pg_config
import psycopg2

class DashDAO:
    def __init__(self):

        connection_url = "dbname=%s user=%s password=%s" % (pg_config['dbname'],
                                                            pg_config['user'],
                                                            pg_config['passwd'])
        self.conn = psycopg2._connect(connection_url)

    #Get likes in a day
    def getLikesPerDate(self, date):
        cursor = self.conn.cursor()
        query = "select sum(likes) " \
                "from message " \
                "where date = %s;"
        cursor.execute(query, (date,))
        result = cursor.fetchone()
        if result == []:
            return None
        return result

    #Get dislikes in a day
    def getDislikesPerDate(self, date):
        cursor = self.conn.cursor()
        query = "select sum(dislikes) " \
                "from message " \
                "where date = %s;"
        cursor.execute(query, (date,))
        result = cursor.fetchone()
        if result == []:
            return None
        return result

    #Get number of messages in a day
    def getTotalMessagesPerDate(self, date):
        cursor = self.conn.cursor()
        query = "select count(*) " \
                "from message " \
                "where date = %s;"
        cursor.execute(query, (date,))
        result = cursor.fetchone()
        if result == []:
            return None
        return result

    #Get total replies in a day
    def getTotalRepliesPerDate(self, date):
        cursor = self.conn.cursor()
        query = "select count(*) " \
                "from message as M, reply as R " \
                "where M.date = %s and R.msg_id = M.msg_id;"
        cursor.execute(query, (date,))
        result = cursor.fetchone()
        if result == []:
            return None
        return result

    #Get hashtags ordered in descending config (freq)
    def getOrderedHashtagFrequency(self, date):
        cursor = self.conn.cursor()
        query = "select H.hash_text, count(*) " \
                "from hashtag as H, message as M " \
                "where H.msg_id = M.msg_id " \
                "and M.date = %s " \
                "group by hash_text " \
                "order by count(*) DESC " \
                "limit 10"
        cursor.execute(query, (date,))
        result = []
        for row in cursor:
            result.append(row)
        if result == []:
            return None
        return result

    #Get number of active users on a day
    def getActiveUsersForDate(self, date):
        cursor = self.conn.cursor()
        query= "select P.username, count(*) as messages " \
               "from person as P, message as M " \
               "where P.person_id = M.person_id " \
               "and M.date = %s " \
               "group by P.username " \
               "order by count(*) DESC " \
               "limit 10"
        cursor.execute(query, (date,))
        result = []
        for row in cursor:
            result.append(row)
        if result == []:
            return None
        return result

    ##################################################
    def getCountByHashtagId(self):
        cursor = self.conn.cursor()
        query = "select hash_text, count(*) " \
                "from hashtag " \
                "group by hash_text " \
                "order by count(*) desc " \
                "limit 5"
        cursor.execute(query)
        result = []
        for row in cursor:
            result.append(row)
        return result

    def getCountByActiveUsersId(self):
        cursor = self.conn.cursor()
        query = "select person_id, username, count(username) " \
                "from message " \
                "where date in (select date from message group by date order by date desc limit 5) " \
                "group by person_id, username " \
                "order by count(username) desc " \
                "limit 10;"
        cursor.execute(query)
        result = []
        for row in cursor:
            result.append(row)
        return result

    def getCountByDislikesId(self):
        cursor = self.conn.cursor()
        query = "select date, count(date) " \
                "from message as M, react as R " \
                "where M.msg_id = R.msg_id " \
                "and R.dislikes = true " \
                "group by date " \
                "order by date desc " \
                "limit 5;"
        cursor.execute(query)
        result = []
        for row in cursor:
            result.append(row)
        return result

    def getCountByLikesId(self):
        cursor = self.conn.cursor()
        query = "select date, count(date) " \
                "from message as M, react as R " \
                "where M.msg_id = R.msg_id " \
                "and R.likes = true " \
                "group by date " \
                "order by date desc " \
                "limit 5;"
        cursor.execute(query)
        result = []
        for row in cursor:
            result.append(row)
        return result

    def getCountByMessagesId(self):
        cursor = self.conn.cursor()
        query = "select date, count(date) " \
                "from message " \
                "group by date " \
                "order by date desc " \
                "limit 5;"
        cursor.execute(query)
        result = []
        for row in cursor:
            result.append(row)
        return result

    def getCountByRepliesId(self):
        cursor = self.conn.cursor()
        query = "select date, count(date) " \
                "from message as M, reply as R " \
                "where M.msg_id = R.msg_id " \
                "group by date " \
                "order by date desc " \
                "limit 5;"
        cursor.execute(query)
        result = []
        for row in cursor:
            result.append(row)
        return result