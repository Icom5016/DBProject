(function() {

    var app = angular.module('MessagingAppUI',['ngRoute']);

    app.config(['$routeProvider', '$locationProvider', function ($routeProvider, $locationProvider) {
        $routeProvider.when('/user', {
            templateUrl: 'pages/user.html',
            controller: 'UserController',
            controllerAs : 'userCtrl'
        }).when('/user/:user_id', {
            templateUrl: 'pages/userdetails.html',
            controller: 'UserDetailController',
            controllerAs : 'userDetailCtrl'
        }).otherwise({
            redirectTo: '/user'
        });
    }]);
})();
