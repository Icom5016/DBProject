#Databse configuration information

pg_config = {
    'user' : 'ubuntu',
    'passwd' : 'lloydsucks7',
    'dbname' : 'messageappdb'
}