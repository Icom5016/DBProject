from flask import Flask, request
from dashhandler.dashhandler import DashHandler
from flask_cors import CORS, cross_origin

#ACTIVATE
app = Flask(__name__)

#Apply CORS to this app
CORS(app)

#RoutesForJsons

#GetLikesOnDate
@app.route("/MessagingApp/dashboard/likes/<string:date>", methods=['GET', 'PUT', 'DELETE'])
def getDashLikesForDate(date):
    return DashHandler().getTotalLikesPerDay(date)

#GetDislikesOnDate
@app.route("/MessagingApp/dashboard/dislikes/<string:date>", methods=['GET', 'PUT', 'DELETE'])
def getDashDislikesForDate(date):
    return DashHandler().getTotalDislikesPerDay(date)

#GetMessagesOnDate
@app.route("/MessagingApp/dashboard/msgs/<string:date>", methods=['GET', 'PUT', 'DELETE'])
def getDashTotMsgsForDate(date):
    return DashHandler().getTotalMessagesPerDay(date)

#GetRepliesOnDate
@app.route("/MessagingApp/dashboard/replies/<string:date>", methods=['GET', 'PUT', 'DELETE'])
def getDashTotRepliesForDate(date):
    return DashHandler().getTotalRepliesPerDay(date)

#Get Top 10 hashtags
@app.route("/MessagingApp/dashboard/trending/<string:date>", methods=['GET', 'PUT', 'DELETE'])
def getOrderedHashtagFrequency(date):
    return DashHandler().getOrderedHashtagFrequency(date)

#GetActiveUsersOnDate
@app.route("/MessagingApp/dashboard/users/<string:date>", methods=['GET', 'PUT', 'DELETE'])
def getActiveUsersForDate(date):
    return DashHandler().getActiveUsersForDate(date)

#Get Top 10 hashtags

#Get Top 10 active users

######################################
@app.route('/MessagingApp/dash/countbyhashtagid')
def getCountByHashtagId():
    return DashHandler().getCountByHashtagId()

@app.route('/MessagingApp/dash/countbyactiveuserid')
def getCountByActiveUsersId():
    return DashHandler().getCountByActiveUsersId()

@app.route('/MessagingApp/dash/countbydislikesid')
def getCountByDislikesId():
    return DashHandler().getCountByDislikesId()

@app.route('/MessagingApp/dash/countbylikesid')
def getCountByLikesId():
    return DashHandler().getCountByLikesId()

@app.route('/MessagingApp/dash/countbymessagesid')
def getCountByMessagesId():
    return DashHandler().getCountByMessagesId()

@app.route('/MessagingApp/dash/countbyrepliesid')
def getCountByRepliesId():
    return DashHandler().getCountByRepliesId()

if __name__ == '__main__':
    app.run()